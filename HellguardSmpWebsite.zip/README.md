# HELLGUARD SMP Website Resources & Deployment

This zip file contains the complete source code and configuration for the **HELLGUARD SMP** website:

- **config.yaml**: Complete YAML schema containing all server IPs, ranks, prices, rules, store items, and staff.
- **index.html**: Ready-to-host website with:
  - Floating logo animations for Home, Store, Rules, and Staff sections.
  - Interactive fiery particles background.
  - One-click "Copy IP" with toast notification.
  - Live Minecraft Server Status & player count fetched directly from `api.mcsrvstat.us`.
  - Store section with interactive Perks modal popup & Discord ticket redirection.
  - Server Rules & Punishments tier list.
  - Staff section featuring `rehan_playz` (FOUNDER) & `GenzVort` (OWNER).
- **assets/css/style.css**: Dark fantasy nether theme, glassmorphism, responsive mobile-first styling.
- **assets/js/script.js**: Live API ping engine, particle simulation, modal management, and copy clipboard.
- **assets/images/**: Replace placeholder graphics with your uploaded images:
  - `hellguard_logo.png` -> Your Hellguard SMP Logo
  - `store_banner.jpg` -> Your Store Banner
  - `rules_banner.png` -> Your Rules Crate Image
  - `staff_banner.jpg` -> Your Staff Header Image

### How to host:
1. Upload these files to GitHub Pages, Netlify, Vercel, or your Web Hosting public_html.
2. Put your exact images in `assets/images/` with the respective names.
